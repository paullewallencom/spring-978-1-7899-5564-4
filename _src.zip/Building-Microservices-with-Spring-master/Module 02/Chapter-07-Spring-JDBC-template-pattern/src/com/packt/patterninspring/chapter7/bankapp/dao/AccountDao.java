/**
 * 
 */
package com.packt.patterninspring.chapter7.bankapp.dao;

/**
 * @author Dinesh.Rajput
 *
 */
public interface AccountDao {
	
	Integer totalAccountsByBranch(String branchName);
}
