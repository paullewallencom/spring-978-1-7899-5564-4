package com.packt.patterninspring.chapter7.bankapp.config;

import org.springframework.context.annotation.Configuration;

/**
 * @author Dinesh.Rajput
 *
 */
@Configuration
public class SecurityConfig {
 //have security related bean
}
