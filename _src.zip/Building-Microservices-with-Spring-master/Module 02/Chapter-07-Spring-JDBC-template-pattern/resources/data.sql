INSERT INTO ACCOUNT (id, name, balance) values (1000, 'Dinesh', 20000);
INSERT INTO ACCOUNT (id, name, balance) values (2000, 'Kumar', 40000);
INSERT INTO ACCOUNT (id, name, balance) values (3000, 'Rajput', 60000);