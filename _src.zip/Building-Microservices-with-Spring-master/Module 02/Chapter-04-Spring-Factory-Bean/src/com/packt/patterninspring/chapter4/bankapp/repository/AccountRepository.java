package com.packt.patterninspring.chapter4.bankapp.repository;


/**
 * @author Dinesh Rajput
 *
 */

public class AccountRepository implements IAccountRepository{

}
