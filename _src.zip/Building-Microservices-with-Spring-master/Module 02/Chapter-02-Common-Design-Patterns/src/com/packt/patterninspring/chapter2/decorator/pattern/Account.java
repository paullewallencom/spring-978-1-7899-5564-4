package com.packt.patterninspring.chapter2.decorator.pattern;

public interface Account {
	String getTotalBenefits();
}
