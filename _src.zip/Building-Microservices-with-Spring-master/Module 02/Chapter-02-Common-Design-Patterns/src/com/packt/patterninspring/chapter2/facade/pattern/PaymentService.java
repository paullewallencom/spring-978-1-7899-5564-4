package com.packt.patterninspring.chapter2.facade.pattern;

/**
 * @author Dinesh.Rajput
 *
 */
public class PaymentService {
	public static boolean doPayment(){
		return true;
	}
}
